const nf = () => {
    return (
        <div className="notfound">
            <h2>Not Found</h2>
        </div>
    );
}

export default nf;