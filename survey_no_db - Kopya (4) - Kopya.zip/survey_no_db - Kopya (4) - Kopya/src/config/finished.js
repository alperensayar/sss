const fins = () => {
    return (
        <div className="finished">
            <h2>Thank you for completing the survey! </h2>
        </div>
    );
}

export default fins;           